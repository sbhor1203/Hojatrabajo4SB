import java.util.ArrayList;

public class Arraylist<E> extends StackP<E> {

    private ArrayList<E> lista;

    public ArrayList() {
        lista = new ArrayList<T>();
    }

    public int count() {
        return lista.size();
    }

    public boolean isEmpty() {
        return lista.isEmpty();
    }
    public void push(E e) {
        lista.add(0, e);
    }

    public E pull() {
        return lista.remove(0);
    }

    public E peek() {
        return lista.get(0);
    }
}

    
