public class CalculadoraInfixPostfix {

    class Stack:
        def __init__(self):
            self.items = [];

        def push(self, item):
            self.items.append(item);

        def pop(self):
            return self.items.pop();

        def is_empty(self):
            return len(self.items) == 0;

    /**
     * @return
     */
    def infix_to_postfix(infix):
        precedence = {'^': 3, '*': 2, '/': 2, '+': 1, '-': 1};
        output = [];
        stack = Stack();

        for token in infix.split():
            if token.isnumeric():
                output.append(token);
            elif token in precedence:
                while not stack.is_empty() and stack.items[-1] != '(' and precedence[token] <= precedence.get(stack.items[-1], 0):
                    output.append(stack.pop());
                stack.push(token)
            elif (token == "("):
                stack.push(token)
            elif (token == ')'):
                while not stack.is_empty() and stack.items[-1] (!= '('):
                    output.append(stack.pop())
                stack.pop()

        while not stack.is_empty():
            output.append(stack.pop())

        return ' '.join(output)

def evaluate_postfix(postfix):
    stack = Stack()

    for token in postfix.split():
        if token.isnumeric():
            stack.push(float(token))
        elif token == '+':
            operand2 = stack.pop()
            operand1 = stack.pop()
            stack.push(operand1 + operand2)
        elif token == '-':
            operand2 = stack.pop()
            operand1 = stack.pop()
            stack.push(operand1 - operand2)
        elif token == '*':
            operand2 = stack.pop()
            operand1 = stack.pop()
            stack.push(operand1 * operand2)
        elif token == '/':
            operand2 = stack.pop()
            operand1 = stack.pop()
            stack.push(operand1 / operand2)
        elif token == '^':
            operand2 = stack.pop()
            operand1 = stack.pop()
            stack.push(operand1 ** operand2)

    return stack.pop()


with open('datos.txt', 'r') as f:
    infix = f.readline().strip()

# Convertir la expresión infix a postfix
postfix = infix_to_postfix(infix)

# Evaluar la expresión postfix
result = evaluate_postfix(postfix)

# Imprimir el resultado de la expresión postfix
print(result)
    
}
