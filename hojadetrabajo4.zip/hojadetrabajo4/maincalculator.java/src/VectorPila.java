import java.util.Vector;

public class VectorPila<E> extends Abstractpila<E> {
    
    private Vector<E> stack = new Vector<E>();
    public void push(E item) {
        stack.add(item);
        size++;
    }
    public E pop() {
        if(empty()) {
            throw new EmptyStackException("Error");
        }
        size--;
        return stack.remove(size);
    }
    public E peek() {
        if(empty()) {
            throw new EmptyStackException("Error");
        }
        return stack.get(size-1);
    }
}