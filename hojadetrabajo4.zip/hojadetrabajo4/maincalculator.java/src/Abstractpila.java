public abstract class Abstractpila<E> implements Pila<E> {
    protected int size;
    public boolean empty() {
        return size == 0;
    }
}