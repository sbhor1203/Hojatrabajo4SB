public class Factorythem {

    public static <T> StackP<T> make_stack(int e) throws IllegalArgumentException {
        switch (e) {
            case 1:
                return new Arraylist<T>();
                
            case 2: 
                return new VectorPila<T>();
            case 3: 
                return new StackP<T>();
            case 4: 
                return new SimplementeEncadenada<T>();
            default:
                throw new IllegalArgumentException("Dato invalido");
        }
    
}
