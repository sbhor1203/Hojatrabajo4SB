public class StackP<T> {
    void push(E e);
   
	
}
