public class SimplementeEncadenada<E> extends AbstractLista<E> {
    private Nodo<E> head;
    public SimplementeEncadenada() {
        head = null;
    }
    public E get(int index) {
        if(index < 0 || index >= size) {
            throw new IndexOutOfBoundsException();
        }
        Nodo<E> current = head;
        for(int i=0; i<index; i++) {
            current = current.getNext();
        }
        return current.getItem();
    }
    public void add(E item)