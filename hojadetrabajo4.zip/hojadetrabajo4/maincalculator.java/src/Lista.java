public interface Lista<E> {
    public int size();
    public boolean isEmpty();
    public E get(int index);
    public void add(E item);
    public void add(int index, E item);
    public E remove(int index);
}